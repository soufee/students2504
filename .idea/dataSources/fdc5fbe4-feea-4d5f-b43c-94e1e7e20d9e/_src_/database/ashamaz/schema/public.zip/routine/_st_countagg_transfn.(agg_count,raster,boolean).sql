CREATE FUNCTION _st_countagg_transfn (agg agg_count, rast raster, exclude_nodata_value boolean) RETURNS agg_count
	LANGUAGE plpgsql
AS $$
	DECLARE
		rtn_agg agg_count;
	BEGIN
		rtn_agg :=  public.__ST_countagg_transfn(
			agg,
			rast,
			1, exclude_nodata_value,
			1
		);
		RETURN rtn_agg;
	END;
	
$$
