CREATE FUNCTION postgis_scripts_build_date () RETURNS text
	LANGUAGE sql
AS $$
SELECT '2017-02-06 16:05:37'::text AS version
$$
