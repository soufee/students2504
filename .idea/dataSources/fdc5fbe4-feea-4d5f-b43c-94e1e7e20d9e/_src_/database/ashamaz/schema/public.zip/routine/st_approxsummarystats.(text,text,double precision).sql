CREATE FUNCTION st_approxsummarystats (rastertable text, rastercolumn text, sample_percent double precision) RETURNS summarystats
	LANGUAGE sql
AS $$
 SELECT public._ST_summarystats($1, $2, 1, TRUE, $3) 
$$
