CREATE FUNCTION st_astiff (rast raster, nbands integer[], options text[] DEFAULT NULL::text[], srid integer DEFAULT NULL::integer) RETURNS bytea
	LANGUAGE sql
AS $$
 SELECT st_astiff(st_band($1, $2), $3, $4) 
$$
