CREATE FUNCTION st_distinct4ma (matrix double precision[], nodatamode text, VARIADIC args text[]) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT COUNT(DISTINCT unnest)::float FROM unnest($1) 
$$
