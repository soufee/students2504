CREATE FUNCTION st_dumpvalues (rast raster, nband integer, exclude_nodata_value boolean DEFAULT true) RETURNS double precision[]
	LANGUAGE sql
AS $$
 SELECT valarray FROM public.ST_dumpvalues($1, ARRAY[$2]::integer[], $3) 
$$
