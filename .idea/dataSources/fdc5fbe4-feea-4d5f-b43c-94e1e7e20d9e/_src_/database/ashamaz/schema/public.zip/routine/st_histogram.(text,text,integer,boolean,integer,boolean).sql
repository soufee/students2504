CREATE FUNCTION st_histogram (rastertable text, rastercolumn text, nband integer, exclude_nodata_value boolean, bins integer, "right" boolean, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision) RETURNS SETOF record
	LANGUAGE sql
AS $$
 SELECT public._ST_histogram($1, $2, $3, $4, 1, $5, NULL, $6) 
$$
