CREATE FUNCTION st_isvalid (geometry, integer) RETURNS boolean
	LANGUAGE sql
AS $$
SELECT (public.ST_isValidDetail($1, $2)).valid
$$
