CREATE FUNCTION st_linestringfromwkb (bytea) RETURNS geometry
	LANGUAGE sql
AS $$
	SELECT CASE WHEN public.geometrytype(public.ST_GeomFromWKB($1)) = 'LINESTRING'
	THEN public.ST_GeomFromWKB($1)
	ELSE NULL END
	
$$
