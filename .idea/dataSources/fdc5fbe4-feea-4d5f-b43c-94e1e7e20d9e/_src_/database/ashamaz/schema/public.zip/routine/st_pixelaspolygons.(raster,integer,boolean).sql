CREATE FUNCTION st_pixelaspolygons (rast raster, band integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, OUT geom geometry, OUT val double precision, OUT x integer, OUT y integer) RETURNS SETOF record
	LANGUAGE sql
AS $$
 SELECT geom, val, x, y FROM public._ST_pixelaspolygons($1, $2, NULL, NULL, $3) 
$$
