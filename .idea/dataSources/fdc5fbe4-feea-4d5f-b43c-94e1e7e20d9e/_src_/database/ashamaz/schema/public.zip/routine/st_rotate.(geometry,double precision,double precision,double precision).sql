CREATE FUNCTION st_rotate (geometry, double precision, double precision, double precision) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT public.ST_Affine($1,  cos($2), -sin($2), 0,  sin($2),  cos($2), 0, 0, 0, 1,	$3 - cos($2) * $3 + sin($2) * $4, $4 - sin($2) * $3 - cos($2) * $4, 0)
$$
