CREATE FUNCTION st_scale (geometry, double precision, double precision, double precision) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT public.ST_Scale($1, public.ST_MakePoint($2, $3, $4))
$$
