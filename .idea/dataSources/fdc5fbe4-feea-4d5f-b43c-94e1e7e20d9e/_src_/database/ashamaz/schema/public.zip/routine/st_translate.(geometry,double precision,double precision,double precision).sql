CREATE FUNCTION st_translate (geometry, double precision, double precision, double precision) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT public.ST_Affine($1, 1, 0, 0, 0, 1, 0, 0, 0, 1, $2, $3, $4)
$$
